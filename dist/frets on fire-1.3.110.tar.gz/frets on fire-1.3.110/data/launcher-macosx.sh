#!/bin/sh
cd "$(dirname "$0")"
LD_LIBRARY_PATH=../Frameworks exec ./FretsOnFire.bin

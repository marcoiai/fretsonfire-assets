####################################################################
# -*- coding: iso-8859-1 -*-                                        #
#                                                                   #
# Frets on Fire                                                     #
# Copyright (C) 2006 Sami Ky?stil?                                  #
#                                                                   #
# This program is free software; you can redistribute it and/or     #
# modify it under the terms of the GNU General Public License       #
# as published by the Free Software Foundation; either version 2    #
# of the License, or (at your option) any later version.            #
#                                                                   #
# This program is distributed in the hope that it will be useful,   #
# but WITHOUT ANY WARRANTY; without even the implied warranty of    #
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     #
# GNU General Public License for more details.                      #
#                                                                   #
# You should have received a copy of the GNU General Public License #
# along with this program; if not, write to the Free Software       #
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,        #
# MA  02110-1301, USA.                                              #
#####################################################################

from __future__ import division
import Log
import Config
#import Image
import pygame
from io import StringIO
#import PngImagePlugin
import PIL.Image
from PIL.Image import Image
from OpenGL.GL import *
from OpenGL.GLU import *
from OpenGL import GL, GLU
from queue import Queue, Empty
from io import BytesIO

Config.define("opengl", "supportfbo", bool, False)

try:
  from glew import *
except ImportError:
  #Log.warn("GLEWpy not found -> Emulating Render to texture functionality.")
  pass

class TextureException(Exception):
  pass

# A queue containing (function, args) pairs that clean up deleted OpenGL handles.
# The functions are called in the main OpenGL thread.
cleanupQueue = Queue()

class Framebuffer:
  fboSupported = None

  def __init__(self, texture, width, height, generateMipmap = False):
    self.emulated       = not self._fboSupported()
    self.size           = (width, height)
    self.colorbuf       = texture
    self.generateMipmap = generateMipmap
    self.fb             = 0
    self.depthbuf       = 0
    self.stencilbuf     = 0
    
    if self.emulated:
      if (width & (width - 1)) or (height & (height - 1)):
        raise TextureException("Only power of two render target textures are supported when frame buffer objects support is missing.")
    else:
      self.fb             = glGenFramebuffersEXT(1)[0]
      self.depthbuf       = glGenRenderbuffersEXT(1)[0]
      self.stencilbuf     = glGenRenderbuffersEXT(1)[0]
      glBindFramebufferEXT(GL.GL_FRAMEBUFFER_EXT, self.fb)
      self._checkError()
      
    glBindTexture(GL.GL_TEXTURE_2D, self.colorbuf)
    glTexParameterf(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MIN_FILTER, GL.GL_LINEAR)
    # PyOpenGL does not support NULL textures, so we must make a temporary buffer here
    glTexImage2D(GL.GL_TEXTURE_2D, 0, GL.GL_RGB, width, height, 0, GL.GL_RGB, GL.GL_UNSIGNED_BYTE, "\x00" * (width * height * 4))
    self._checkError()
    
    if self.emulated:
      return
    
    glBindFramebufferEXT(GL.GL_FRAMEBUFFER_EXT, self.fb)

    try:
      glFramebufferTexture2DEXT(GL.GL_FRAMEBUFFER_EXT,
                                GL.GL_COLOR_ATTACHMENT0_EXT,
                                GL.GL_TEXTURE_2D, self.colorbuf, 0)
      self._checkError()
      
      # On current NVIDIA hardware, the stencil buffer must be packed
      # with the depth buffer (GL.GL_NV_packed_depth_stencil) instead of
      # separate binding, so we must check for that extension here
      if glewGetExtension("GL.GL_NV_packed_depth_stencil"):
        GL_DEPTH_STENCIL_EXT = 0x84F9
      
        glBindRenderbufferEXT(GL.GL_RENDERBUFFER_EXT, self.depthbuf)
        glRenderbufferStorageEXT(GL.GL_RENDERBUFFER_EXT,
                                 GL_DEPTH_STENCIL_EXT, width, height)
        glFramebufferRenderbufferEXT(GL.GL_FRAMEBUFFER_EXT,
                                     GL.GL_DEPTH_ATTACHMENT_EXT,
                                     GL.GL_RENDERBUFFER_EXT, self.depthbuf)
        self._checkError()
      else:
        glBindRenderbufferEXT(GL.GL_RENDERBUFFER_EXT, self.depthbuf)
        glRenderbufferStorageEXT(GL.GL_RENDERBUFFER_EXT,
                                 GL.GL_DEPTH_COMPONENT24, width, height)
        glFramebufferRenderbufferEXT(GL.GL_FRAMEBUFFER_EXT,
                                     GL.GL_DEPTH_ATTACHMENT_EXT,
                                     GL.GL_RENDERBUFFER_EXT, self.depthbuf)
        self._checkError()
        glBindRenderbufferEXT(GL.GL_RENDERBUFFER_EXT, self.stencilbuf)
        glRenderbufferStorageEXT(GL.GL_RENDERBUFFER_EXT,
                                 GL.GL_STENCIL_INDEX_EXT, width, height)
        glFramebufferRenderbufferEXT(GL.GL_FRAMEBUFFER_EXT,
                                     GL.GL_STENCIL_ATTACHMENT_EXT,
                                     GL.GL_RENDERBUFFER_EXT, self.stencilbuf)
        self._checkError()
    finally:
      glBindFramebufferEXT(GL.GL_FRAMEBUFFER_EXT, 0)

  def __del__(self):
    # Queue the buffers to be deleted later
    try:
      cleanupQueue.put((glDeleteBuffers, [3, [self.depthbuf, self.stencilbuf, self.fb]]))
    except NameError:
      pass
      
  def _fboSupported(self):
    if Framebuffer.fboSupported is not None:
      return Framebuffer.fboSupported
    Framebuffer.fboSupported = False
    
    if not Config.get("opengl", "supportfbo"):
      Log.warn("Frame buffer object support disabled in configuration.")
      return False
  
    if not "glewGetExtension" in globals():
      Log.warn("GLEWpy not found, so render to texture functionality disabled.")
      return False

    GL.glewInit()

    if not GL.glewGetExtension("GL.GL_EXT_framebuffer_object"):
      Log.warn("No support for framebuffer objects, so render to texture functionality disabled.")
      return False
      
    if GL.glGetString(GL.GL_VENDOR) == "ATI Technologies Inc.":
      Log.warn("Frame buffer object support disabled until ATI learns to make proper OpenGL drivers (no stencil support).")
      return False
      
    Framebuffer.fboSupported = True
    return True

  def _checkError(self):
    pass
    # No glGetError() anymore...
    #err = glGetError()
    #if (err != GL.GL_NO_ERROR):
    #  raise TextureException(gluErrorString(err))

  def setAsRenderTarget(self):
    if not self.emulated:
      glBindTexture(GL.GL_TEXTURE_2D, 0)
      glBindFramebufferEXT(GL.GL_FRAMEBUFFER_EXT, self.fb)
      self._checkError()

  def resetDefaultRenderTarget(self):
    glTexParameterf(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MAG_FILTER, GL.GL_LINEAR)
    if not self.emulated:
      glBindFramebufferEXT(GL.GL_FRAMEBUFFER_EXT, 0)
      glBindTexture(GL.GL_TEXTURE_2D, self.colorbuf)
      if self.generateMipmap:
        glGenerateMipmapEXT(GL.GL_TEXTURE_2D)
        glTexParameterf(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MIN_FILTER, GL.GL_LINEAR_MIPMAP_LINEAR)
      else:
        glTexParameterf(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MIN_FILTER, GL.GL_LINEAR)
    else:
      glBindTexture(GL.GL_TEXTURE_2D, self.colorbuf)
      glCopyTexSubImage2D(GL.GL_TEXTURE_2D, 0, 0, 0, 0, 0, self.size[0], self.size[1])
      glTexParameterf(GL.GL_TEXTURE_2D, GL.GL_TEXTURE_MIN_FILTER, GL.GL_LINEAR)
      
class Texture:
  """Represents an OpenGL texture, optionally loaded from disk in any format supported by PIL"""

  def __init__(self, name = None, target = GL.GL_TEXTURE_2D):
    # Delete all pending textures
    try:
      func, args = cleanupQueue.get_nowait()
      func(*args)
    except Empty:
      pass
    
    self.texture = glGenTextures(1)
    self.texEnv = GL.GL_MODULATE
    self.glTarget = target
    self.framebuffer = None

    self.setDefaults()
    self.name = name

    if name:
      self.loadFile(name)

  def loadFile(self, name):
    """Load the texture from disk, using PIL to open the file"""
    self.loadImage(PIL.Image.open(name))
    self.name = name

  def loadImage(self, image):
    """Load the texture from a PIL image"""
    image = image.transpose(PIL.Image.FLIP_TOP_BOTTOM)
    
    #print('########################################')
    #print(image)
    
    if image.mode == "RGBA":
        string = BytesIO()
        image.save(string, 'png')                                                   
        #print('???????????????????')
        #print(string.getvalue())
        #string = image.Str StringIO #tostring("raw", "RGBA") 
        self.loadRaw(image.size, string.getvalue(), GL.GL_RGBA, 4)
    elif image.mode == "RGB":
      string = BytesIO()
      image.save(string, 'png')
      #print('@@@@@@@@@@@@@@@@@@@@@@@@')
      #print(string.getvalue())
      
      self.loadRaw(image.size, string.getvalue(), GL.GL_RGB, 3)
      #self.loadRaw(image.size, string, GL.GL_RGB, 3)
    elif image.mode == "L":
      string = BytesIO()
      image.save(string, 'png')
      self.loadRaw(image.size, string.getValue(), GL.GL_LUMINANCE, 1)
    else:
      raise TextureException("Unsupported image mode '%s'" % image.mode)

  def prepareRenderTarget(self, width, height, generateMipmap = True):
    self.framebuffer = Framebuffer(self.texture, width, height, generateMipmap)
    self.pixelSize   = (width, height)
    self.size        = (1.0, 1.0)

  def setAsRenderTarget(self):
    assert self.framebuffer
    self.framebuffer.setAsRenderTarget()

  def resetDefaultRenderTarget(self):
    assert self.framebuffer
    self.framebuffer.resetDefaultRenderTarget()

  def nextPowerOfTwo(self, n):
    m = 1
    while m < n:
      m <<= 1
    return m

  def loadSurface(self, surface, monochrome = False, alphaChannel = False):
    """Load the texture from a pygame surface"""

    # make it a power of two
    self.pixelSize = w, h = surface.get_size()
    w2, h2 = [self.nextPowerOfTwo(x) for x in [w, h]]
    if w != w2 or h != h2:
      s = pygame.Surface((w2, h2), pygame.SRCALPHA, 32)
      s.blit(surface, (0, h2 - h))
      surface = s
    
    if monochrome:
      # pygame doesn't support monochrome, so the fastest way
      # appears to be using PIL to do the conversion.
      string = PIL.Image.tostring(surface, "RGB")
      image = PIL.Image.fromstring("RGB", surface.get_size(), string).convert("L")
      string = image.tostring('raw', 'L', 0, -1)
      self.loadRaw(surface.get_size(), string, GL.GL_LUMINANCE, GL.GL_INTENSITY8)
    else:
      if alphaChannel:
        string = pygame.image.tostring(surface, "RGBA", True)
        self.loadRaw(surface.get_size(), string, GL.GL_RGBA, 4)
      else:
        string = pygame.image.tostring(surface, "RGB", True)
        self.loadRaw(surface.get_size(), string, GL.GL_RGB, 3)
    self.size = (w / w2, h / h2)

  def loadSubsurface(self, surface, position = (0, 0), monochrome = False, alphaChannel = False):
    """Load the texture from a pygame surface"""

    if monochrome:
      # pygame doesn't support monochrome, so the fastest way
      # appears to be using PIL to do the conversion.
      string = pygame.image.tostring(surface, "RGB")
      image = Image.fromstring("RGB", surface.get_size(), string).convert("L")
      string = image.tostring('raw', 'L', 0, -1)
      self.loadSubRaw(surface.get_size(), position, string, GL.GL_INTENSITY8)
    else:
      if alphaChannel:
        string = pygame.image.tostring(surface, "RGBA", True)
        self.loadSubRaw(surface.get_size(), position, string, GL.GL_RGBA)
      else:
        string = pygame.image.tostring(surface, "RGB", True)
        self.loadSubRaw(surface.get_size(), position, string, GL.GL_RGB)

  def loadRaw(self, size, string, format, components):
    """Load a raw image from the given string. 'format' is a constant such as
       GL.GL_RGB or GL.GL_RGBA that can be passed to gluBuild2DMipmaps.
       """
    self.pixelSize = size
    self.size = (1.0, 1.0)
    self.format = format
    self.components = components
    (w, h) = size
    Texture.bind(self)
    glPixelStorei(GL.GL_UNPACK_ALIGNMENT, 1)
    GLU.gluBuild2DMipmaps(self.glTarget, components, w, h, format, GL.GL_UNSIGNED_BYTE, string)

  def loadSubRaw(self, size, position, string, format):
    Texture.bind(self)
    glPixelStorei(GL.GL_UNPACK_ALIGNMENT, 1)
    glTexSubImage2D(self.glTarget, 0, position[0], position[1], size[0], size[1], format, GL.GL_UNSIGNED_BYTE, string)

  def loadEmpty(self, size, format):
    self.pixelSize = size
    self.size = (1.0, 1.0)
    self.format = format
    Texture.bind(self)
    glTexImage2D(GL.GL_TEXTURE_2D, 0, format, size[0], size[1], 0,
                 format, GL.GL_UNSIGNED_BYTE, "\x00" * (size[0] * size[1] * 4))

  def setDefaults(self):
    """Set the default OpenGL options for this texture"""
    self.setRepeat()
    self.setFilter()
    glHint(GL.GL_PERSPECTIVE_CORRECTION_HINT, GL.GL_NICEST)

  def setRepeat(self, u=GL.GL_CLAMP_TO_EDGE, v=GL.GL_CLAMP_TO_EDGE):
    Texture.bind(self)
    glTexParameteri(self.glTarget, GL.GL_TEXTURE_WRAP_S, u)
    glTexParameteri(self.glTarget, GL.GL_TEXTURE_WRAP_T, v)

  def setFilter(self, min=GL.GL_LINEAR_MIPMAP_LINEAR, mag=GL.GL_LINEAR):
    Texture.bind(self)
    glTexParameteri(self.glTarget, GL.GL_TEXTURE_MIN_FILTER, min)
    glTexParameteri(self.glTarget, GL.GL_TEXTURE_MAG_FILTER, mag)

  def __del__(self):
    # Queue this texture to be deleted later
    try:
      cleanupQueue.put((glDeleteTextures, [self.texture]))
    except NameError:
      pass

  def bind(self, glTarget = None):
    """Bind this texture to self.glTarget in the current OpenGL context"""
    if not glTarget:
        glTarget = self.glTarget
    glBindTexture(glTarget, self.texture)
    glTexEnvf(GL.GL_TEXTURE_ENV, GL.GL_TEXTURE_ENV_MODE, self.texEnv)

#
# Texture atlas
#
TEXTURE_ATLAS_SIZE = 1024

class TextureAtlasFullException(Exception):
  pass

class TextureAtlas(object):
  def __init__(self, size = TEXTURE_ATLAS_SIZE):
    self.texture      = Texture()
    self.cursor       = (0, 0)
    self.rowHeight    = 0
    self.surfaceCount = 0
    self.texture.loadEmpty((size, size), GL.GL_RGBA)

  def add(self, surface, margin = 0):
    w, h = surface.get_size()
    x, y = self.cursor

    w += margin
    h += margin

    if w > self.texture.pixelSize[0] or h > self.texture.pixelSize[1]:
      raise ValueError("Surface is too big to fit into atlas.")

    if x + w >= self.texture.pixelSize[0]:
      x = 0
      y += self.rowHeight
      self.rowHeight = 0

    if y + h >= self.texture.pixelSize[1]:
      Log.debug("Texture atlas %s full after %d surfaces." % (self.texture.pixelSize, self.surfaceCount))
      raise TextureAtlasFullException()

    self.texture.loadSubsurface(surface, position = (x, y), alphaChannel = True)

    self.surfaceCount += 1
    self.rowHeight = max(self.rowHeight, h)
    self.cursor = (x + w, y + h)

    # Return the coordinates for the uploaded texture patch
    w -= margin
    h -= margin
    return  x      / float(self.texture.pixelSize[0]),  y      / float(self.texture.pixelSize[1]), \
           (x + w) / float(self.texture.pixelSize[0]), (y + h) / float(self.texture.pixelSize[1])

  def bind(self):
    self.texture.bind()
